CREATE VIEW v_inventory_with_expiration_date AS
  SELECT
    `zzzz_supermarket`.`inventory`.`barcode`                                                                     AS `barcode`,
    `zzzz_supermarket`.`inventory`.`production_date`                                                             AS `production_date`,
    `zzzz_supermarket`.`inventory`.`manufacturer`                                                                AS `manufacturer`,
    `zzzz_supermarket`.`inventory`.`qty_in_stock`                                                                AS `qty_in_stock`,
    `zzzz_supermarket`.`inventory`.`qty_on_shelf`                                                                AS `qty_on_shelf`,
    (`zzzz_supermarket`.`inventory`.`production_date` +
     INTERVAL `zzzz_supermarket`.`product`.`shelf_life` HOUR)                                                    AS `expiration_date`,
    `zzzz_supermarket`.`product`.`shelf_life`                                                                    AS `shelf_life`
  FROM (`zzzz_supermarket`.`inventory`
    JOIN `zzzz_supermarket`.`product`
      ON ((`zzzz_supermarket`.`inventory`.`barcode` = `zzzz_supermarket`.`product`.`barcode`)));
